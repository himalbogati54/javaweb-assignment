# School Management System

School Management System using JSP Servelet And also used UI and UX concepts
![image](https://drive.google.com/uc?export=view&id=1EWOWIJkhX7mCNL3UaylF2yXUcyTmE1zz)


[![Build Status](https://img.shields.io/badge/Powerd%20By-Eclipse%20Oxygen-green.svg)](https://www.eclipse.org/downloads/packages/release/oxygen)

[![Build Status](https://img.shields.io/badge/Source%20Editor-Visual%20Code-blue.svg)](https://code.visualstudio.com/)



  







### Technology Used

Dillinger uses a number of open source projects to work properly:

* Jsp Servelet - HTML enhanced for web apps!
* Visual Code - Awsome Source code editor
*  Bootstrap - great UI boilerplate for modern web apps
* Eclipse Oxygen - IDE for Java EE application

### Used Design Pattern 
* Model View Controller (MVC)

### Contributing

* Bawantha Thilan - Developer - [https://stackoverflow.com/story/bawantha]
* github repo - [https://github.com/bawantharathnayakasliit/OOPProject]

### Authors
* Bawantha Thilan 
* Sithira
    







